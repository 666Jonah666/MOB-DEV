package com.example.laboratornaya_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    TextView tvInfo;
    EditText etInput;
    Button bControl;
    Integer random1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        random1 = Random_number(101);
        setContentView(R.layout.activity_main);
        tvInfo = (TextView)findViewById(R.id.textView);
        etInput = (EditText)findViewById(R.id.editText);
        bControl = (Button)findViewById(R.id.button);
    }
    public void onClick(View v){

        if (bControl.getText().toString().equals(getResources().getString(R.string.play_more))){
            bControl.setText(getResources().getString(R.string.input_value));
            tvInfo.setText(getResources().getString(R.string.try_to_guess));
            random1 = Random_number(101);
        }
        else {
            Integer user_input;
            user_input = Integer.parseInt(etInput.getText().toString());
            if (user_input > random1){
                tvInfo.setText(getResources().getString(R.string.ahead));
            }
            else if(user_input < random1){
                tvInfo.setText(getResources().getString(R.string.behind));
            }
            else if(user_input == random1){
                tvInfo.setText(getResources().getString(R.string.hit));
                bControl.setText(getResources().getString(R.string.play_more));
            }
        }

    }
    public int Random_number(int range){
        Integer a;
        Random rand = new Random();
        a = rand.nextInt(range);
        return a;
    }
}