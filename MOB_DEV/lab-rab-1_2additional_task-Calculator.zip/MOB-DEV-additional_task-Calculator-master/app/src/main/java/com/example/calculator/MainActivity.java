package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.text.DecimalFormat;
import androidx.appcompat.app.AppCompatActivity;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class MainActivity extends AppCompatActivity {
    EditText mainEdit;
    Button oneButton;
    Button twoButton;
    Button threeButton;
    Button fourButton;
    Button fiveButton;
    Button sixButton;
    Button sevenButton;
    Button eightButton;
    Button nineButton;
    Button zeroButton;
    Button resultButton;
    Button clearButton;
    Button plusButton;
    Button minusButton;
    Button multiplyButton;
    Button divisionButton;
    String s = "";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainEdit = (EditText) findViewById(R.id.edit_text);
        oneButton = (Button) findViewById(R.id.one_btn);
        twoButton = (Button) findViewById(R.id.two_btn);
        threeButton = (Button) findViewById(R.id.three_btn);
        fourButton = (Button) findViewById(R.id.four_btn);
        fiveButton = (Button) findViewById(R.id.five_btn);
        sixButton = (Button) findViewById(R.id.six_btn);
        sevenButton = (Button) findViewById(R.id.seven_btn);
        eightButton = (Button) findViewById(R.id.eight_btn);
        nineButton = (Button) findViewById(R.id.nine_btn);
        zeroButton = (Button) findViewById(R.id.zero_btn);
        resultButton = (Button) findViewById(R.id.result_btn);
        clearButton = (Button) findViewById(R.id.clear_btn);
        plusButton = (Button) findViewById(R.id.plus_btn);
        minusButton = (Button) findViewById(R.id.minus_btn);
        multiplyButton = (Button) findViewById(R.id.multiply_btn);
        divisionButton = (Button) findViewById(R.id.division_btn);
        oneButton.setOnClickListener(clickListener1);
        twoButton.setOnClickListener(clickListener2);
        threeButton.setOnClickListener(clickListener3);
        fourButton.setOnClickListener(clickListener4);
        fiveButton.setOnClickListener(clickListener5);
        sixButton.setOnClickListener(clickListener6);
        sevenButton.setOnClickListener(clickListener7);
        eightButton.setOnClickListener(clickListener8);
        nineButton.setOnClickListener(clickListener9);
        zeroButton.setOnClickListener(clickListener0);
        resultButton.setOnClickListener(clickListener_result);
        clearButton.setOnClickListener(clickListener_clear);
        plusButton.setOnClickListener(clickListener_plus);
        minusButton.setOnClickListener(clickListener_minus);
        multiplyButton.setOnClickListener(clickListener_multiply);
        divisionButton.setOnClickListener(clickListener_division);

    }

    View.OnClickListener clickListener1 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + "1";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener2 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + "2";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener3 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + "3";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener4 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + "4";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener5 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + "5";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener6 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + "6";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener7 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + "7";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener8 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + "8";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener9 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + "9";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener0 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + "0";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener_result = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            ScriptEngine engine = new ScriptEngineManager().getEngineByName("rhino");
            DecimalFormat format = new DecimalFormat("0.#");
            try {
                double result = 0;
                result = (double) engine.eval(s);
                s = String.valueOf(format.format(result));
            } catch (Exception e) {
                e.printStackTrace();
            }

            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener_clear = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = "";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener_plus = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + " " + "+" + " ";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener_minus = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            s = s + " " + "-" + " ";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener_multiply = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            s = s + " " + "*" + " ";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
    View.OnClickListener clickListener_division = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            s = s + " " + "/" + " ";
            mainEdit.setText(s.toCharArray(), 0, s.length());
        }
    };
}