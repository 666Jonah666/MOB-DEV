package com.example.lab_rab_2_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnImportant, btnHomework, btnShopping;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnImportant = (Button) findViewById(R.id.important_button);
        btnImportant.setOnClickListener(clickImportant);
        btnHomework = (Button) findViewById(R.id.homework_button);
        btnHomework.setOnClickListener(clickHomework);
        btnShopping = (Button) findViewById(R.id.shopping_button);
        btnShopping.setOnClickListener(clickShopping);

    }
    View.OnClickListener clickImportant = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MainActivity.this, ImportantActivity.class);
            startActivity(intent);
        }
    };
    View.OnClickListener clickHomework = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MainActivity.this, HomeworkActivity.class);
            startActivity(intent);
        }
    };
    View.OnClickListener clickShopping = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MainActivity.this, ShoppingActivity.class);
            startActivity(intent);
        }
    };
}