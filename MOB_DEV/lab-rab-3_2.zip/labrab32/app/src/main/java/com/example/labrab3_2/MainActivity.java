package com.example.labrab3_2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnAdd, btnDelete, btnRead;
    EditText etName;
    DBHelper dbHelper;
    private Button btnDatePicker;
    private EditText editTextDate;
    private int mYear, mMonth, mDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAdd = findViewById(R.id.btnAdd);
        btnDelete = findViewById(R.id.btnDelete);
        btnRead = findViewById(R.id.btnRead);
        etName = findViewById(R.id.etName);
        btnAdd.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnRead.setOnClickListener(this);
        dbHelper = new DBHelper(this);
        btnDatePicker = (Button) findViewById(R.id.btn_date);
        editTextDate = (EditText) findViewById(R.id.picked_date);
        btnDatePicker.setOnClickListener(this);
    }

    public void onClick(View v) {

        String name = etName.getText().toString();
        String date = editTextDate.getText().toString();
        ContentValues cv = new ContentValues();
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        switch (v.getId()){
            case R.id.btnAdd:
                cv.put("name", name);
                cv.put("date", date);
                db.insert("mytable", null, cv);
                Log.d("LOG_TAG", "inserted " + name + ", " + date);
                break;
            case R.id.btnDelete:
                db.delete("mytable", null, null);
                Log.d("LOG_TAG", "data deleted");
                break;
            case R.id.btnRead:
                Cursor c = db.query("mytable", null, null, null, null, null, null);
                if (c.moveToFirst()) {
                    Log.d("LOG_TAG", "2 rows");
                    int nameColIndex = c.getColumnIndex("name");
                    int dateColIndex = c.getColumnIndex("date");
                    etName.setText(c.getString(nameColIndex).toCharArray(), 0, c.getString(nameColIndex).length());
                    editTextDate.setText(c.getString(dateColIndex).toCharArray(), 0, c.getString(dateColIndex).length());
                    do {

                    } while (c.moveToNext());
                } else
                    Log.d("LOG_TAG", "no data");
                c.close();
                break;
            case R.id.btn_date:
                callDatePicker();
                break;
            default:
                break;
        }
    }
    public class DBHelper extends SQLiteOpenHelper {
        public DBHelper(Context context) {
            super(context, "MyDB", null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table mytable (name TEXT primary key, date TEXT)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
           // db.execSQL("drop table if exists mytable");
        }
    }

    private void callDatePicker() {

        final Calendar cal = Calendar.getInstance();
        mYear = cal.get(Calendar.YEAR);
        mMonth = cal.get(Calendar.MONTH);
        mDay = cal.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        String editTextDateParam = dayOfMonth + "." + (monthOfYear + 1) + "." + year;
                        editTextDate.setText(editTextDateParam);
                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

}



