package com.example.lab_rab_3_1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnSave, btnLoad;
    EditText etName;
    TextView textView1;
    Spinner spinner;
    SeekBar seekBar;
    ArrayAdapter<CharSequence> adapter;
    private Button btnDatePicker;
    private EditText editTextDate;
    private int mYear, mMonth, mDay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSave = findViewById(R.id.btnSave);
        btnLoad = findViewById(R.id.btnLoad);
        etName = findViewById(R.id.etName);
        btnSave.setOnClickListener(this);
        btnLoad.setOnClickListener(this);


        spinner = (Spinner) findViewById(R.id.spinner);

        adapter = ArrayAdapter.createFromResource(this,
                R.array.planets_array, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        ///
        seekBar = findViewById(R.id.seekBar);
        textView1 = findViewById(R.id.seekBarValue);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                textView1.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        btnDatePicker = (Button) findViewById(R.id.btn_date);
        editTextDate = (EditText) findViewById(R.id.picked_date);
        btnDatePicker.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {


        switch (v.getId()){
            case R.id.btn_date:
                // вызываем диалог с выбором даты
                callDatePicker();
                break;
            case R.id.btnSave:
                save_text();
                break;
            case R.id.btnLoad:
                load_text();
                break;

            default:
                break;
        }
    }
    public void save_text(){
        String name = "";
        String value = "";
        String date = "";
        String group = "";
        SharedPreferences pref = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor ed = pref.edit();
        name = etName.getText().toString();
        value = textView1.getText().toString();
        date = editTextDate.getText().toString();
        group = spinner.getSelectedItem().toString();
        ed.putString("name", name);
        ed.putString("value", value);
        ed.putString("date", date);
        ed.putString("group", group);
        ed.commit();
        Log.i("SPREF", name + value + date + group);
    }
    public void load_text(){
        String name = "";
        String value = "";
        String date = "";
        String group = "";
        SharedPreferences pref1 = getPreferences(MODE_PRIVATE);
        name = pref1.getString("name", "");
        value = pref1.getString("value", "");
        date = pref1.getString("date", "");
        group = pref1.getString("group", "");
        etName.setText(name);
        textView1.setText(value);
        seekBar.setProgress(Integer.parseInt(value));
        editTextDate.setText(date);
        int spinnerPosition = adapter.getPosition(group);
        spinner.setSelection(spinnerPosition);
        //spinner.setAdapter(group);
        Log.i("SPREF", name);
    }
    private void callDatePicker() {

        final Calendar cal = Calendar.getInstance();
        mYear = cal.get(Calendar.YEAR);
        mMonth = cal.get(Calendar.MONTH);
        mDay = cal.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        String editTextDateParam = dayOfMonth + "." + (monthOfYear + 1) + "." + year;
                        editTextDate.setText(editTextDateParam);
                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

}