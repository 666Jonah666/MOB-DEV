package com.example.lab_rab_2_3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ImportantActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    EditText mainEditText;
    Button btnADD;
    ListView mainListView;
    ArrayAdapter mArrayAdapter;
    ArrayList mNameList = new ArrayList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_important);
        mainEditText = (EditText) findViewById(R.id.main_edittext);
        btnADD = (Button) findViewById(R.id.btn_add);
        btnADD.setOnClickListener(clickADD);
        mainListView = findViewById(R.id.main_listview);
        mArrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, mNameList);
        mainListView.setAdapter(mArrayAdapter);
        mainListView.setOnItemClickListener((AdapterView.OnItemClickListener) this);
    }
    View.OnClickListener clickADD = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(!(mNameList.contains(mainEditText.getText().toString()))){
                mNameList.add(mainEditText.getText().toString());
                mArrayAdapter.notifyDataSetChanged();
            } else {
                Toast.makeText(getApplicationContext(), "This task already in list", Toast.LENGTH_LONG).show();
            }
        }

    };
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        AlertDialog.Builder adb=new AlertDialog.Builder(ImportantActivity.this);
        adb.setTitle("Delete?");
        adb.setMessage("Are you sure you want to delete this task?");
        final int positionToRemove = position;
        adb.setNegativeButton("Cancel", null);
        adb.setPositiveButton("Ok", new AlertDialog.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                mNameList.remove(mNameList.get(position).toString());
                mArrayAdapter.notifyDataSetChanged();
            }});
        adb.show();
    }

}